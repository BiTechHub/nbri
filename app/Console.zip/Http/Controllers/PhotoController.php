<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin;
use App\Models\Slider;
use App\Models\Photo;
use App\Models\Teacher;
use App\Models\Submenu;
use App\Models\Menu;
use App\Models\Sitecontent;
use App\Models\Appointment;
use App\Models\Childmenu;
use App\Models\Image_category;
use DB;
use Image;
use Session;
use Redirect;
use Validator;

class PhotoController extends Controller
{
public function uploadslider(Request $request){
    $validatedData = $request->validate([
        'image' => 'required|image|mimes:jpg,png,jpeg,gif,svg|max:8048'
       ]);
  
  	  $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
      $ip = $request->ip();
      $order = DB::table('action_logs')->insert([
          'ip_address' => $ip,
          'action_type' => 'Upload Slider',
          'created_at' => now(),
          'updated_at' => now(),
          'created_by' => session('Loggeduser'),
          'user_id' => session('Loggeduser'),
          'user_name' => $data['LoggeduserInfo']->username
      ]);
  
  
  
       $image = $request->image;
       $heading = $request->input('heading');
       $extenstion = $image->getClientOriginalExtension();
       $imageName = time().'.'.$extenstion;
       $image->move('uploads/', $imageName);
        //$destinationPath = 'public/uploads/';
        //$new_img = Image::make($image->path())->resize(1420, 420);
        //$imageName = time().'.'.$request->image->extension();
        //$new_img->save($destinationPath . $imageName, 80);
       $save = new Slider;
       $save->heading = $heading;
	   $save->heading_hi = $request->heading_hi;
       $save->image = $imageName;
       $save->save();

       return redirect('admin-panel/slider')->with('status', 'Image Has been uploaded');

   }
   public function uploadofficers(Request $request){
    $validatedData = $request->validate([
        'name' => 'required',
        'name_hi' => 'required',
        'deg' => 'required',
        'deg_hi' => 'required',
        'position' => 'required',
        'image' => 'required|image|mimes:jpg,png,jpeg,gif,svg|max:8048'

       ]);
       
     $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
      $ip = $request->ip();
      $order = DB::table('action_logs')->insert([
          'ip_address' => $ip,
          'action_type' => 'Upload Officers',
          'created_at' => now(),
          'updated_at' => now(),
          'created_by' => session('Loggeduser'),
          'user_id' => session('Loggeduser'),
          'user_name' => $data['LoggeduserInfo']->username
      ]);
     
     
     
     
       $image = $request->image;
       $name = $request->input('name');
       $deg = $request->input('deg');
       $position = $request->input('position');
       
       $swrn = Appointment::where('position',$position)->where('isDeleted','N')->first();
       if($swrn){
           return redirect()->back()->with('status','Officers Placing Position is already Selected for any other Officer. Please Select any Other Position.');
       }
       
       $imageName = time().'.'.$request->image->extension();
       $request->image->move(public_path('uploads'), $imageName);
     
       $save = new Appointment;
       $save->name = $name;
       $save->name_hi = $request->name_hi;
       $save->deg = $deg;
       $save->deg_hi = $request->deg_hi;
       $save->position = $position;
       $save->image = $imageName;
       $save->save();

       return redirect('admin-panel/officers')->with('status', 'Content Has been uploaded successfully.');

   }
   public function uploadteacher(Request $request){
    $validatedData = $request->validate([
        'name' => 'required',
        'deg' => 'required',
       ]);

    $save = new Teacher;
    $save->name = $request->input('name');
    $save->subject = $request->input('deg');
    $save->save();
    return redirect('admin-panel/softwares')->with('status', 'Data Has been uploaded');
   }

   public function uploadmenu(Request $request){
    $validatedData = $request->validate([
        'menu' => 'required',
        'menu_hi' => 'required',
       ]);

     $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
      $ip = $request->ip();
      $order = DB::table('action_logs')->insert([
          'ip_address' => $ip,
          'action_type' => 'Upload Menu',
          'created_at' => now(),
          'updated_at' => now(),
          'created_by' => session('Loggeduser'),
          'user_id' => session('Loggeduser'),
          'user_name' => $data['LoggeduserInfo']->username
      ]);
     
       $save = new Menu;
       $save->menu_name = $request->input('menu');
       $save->menu_hi = $request->input('menu_hi');
       $save->save();
       return redirect('admin-panel/addmenu')->with('status', 'Menu Has been uploaded');

   }


public function update_menu(Request $request){
    $validatedData = $request->validate([
        'menu' => 'required',
        'menu_hi' => 'required',
       ]);

	  $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
      $ip = $request->ip();
      $order = DB::table('action_logs')->insert([
          'ip_address' => $ip,
          'action_type' => 'Update Menu',
          'created_at' => now(),
          'updated_at' => now(),
          'created_by' => session('Loggeduser'),
          'updated_by' => session('Loggeduser'),
          'user_id' => session('Loggeduser'),
          'user_name' => $data['LoggeduserInfo']->username
      ]);


       $save = Menu::where('id', $request->user_id)->first();
       $save->menu_name = $request->input('menu');
       $save->menu_hi = $request->input('menu_hi');
       $save->save();
       return redirect('admin-panel/addmenu')->with('status', 'Menu Has been uploaded');

   }


public function update_submenu(Request $request){
    $validatedData = $request->validate([
        'sub_name' => 'required',
        'submenu_hi' => 'required',
       ]);


	  $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
      $ip = $request->ip();
      $order = DB::table('action_logs')->insert([
          'ip_address' => $ip,
          'action_type' => 'Update Menu',
          'created_at' => now(),
          'updated_at' => now(),
          'created_by' => session('Loggeduser'),
          'updated_by' => session('Loggeduser'),
          'user_id' => session('Loggeduser'),
          'user_name' => $data['LoggeduserInfo']->username
      ]);

       $save = Submenu::where('id', $request->user_id)->first();
       $save->sub_name = $request->input('sub_name');
       $save->submenu_hi = $request->input('submenu_hi');
       $save->save();
       return redirect('admin-panel/addsubmenu')->with('status', 'Sub Menu Has been uploaded');

   }

public function uploadsubmenu(Request $request){
    $validatedData = $request->validate([
        'submenu' => 'required',
        'main_cat' => 'required',
        'submenu_hi' => 'required',
       ]);

	  $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
      $ip = $request->ip();
      $order = DB::table('action_logs')->insert([
          'ip_address' => $ip,
          'action_type' => 'Update Submenu',
          'created_at' => now(),
          'updated_at' => now(),
          'created_by' => session('Loggeduser'),
          'updated_by' => session('Loggeduser'),
          'user_id' => session('Loggeduser'),
          'user_name' => $data['LoggeduserInfo']->username
      ]);


       $save = new Submenu;
       $save->sub_name = $request->input('submenu');
       $save->cat_name = $request->input('main_cat');
       $save->submenu_hi = $request->input('submenu_hi');
       $save->save();
       Menu::where('menu_name',$request->input('main_cat'))->update(array('havesub' => 'Yes'));

       return redirect('admin-panel/addsubmenu')->with('status', 'Data Has been uploaded');

   }
   public function uploadchildmenu(Request $request){
    $validatedData = $request->validate([
        'sub_menu' => 'required',
        'main_cat' => 'required',
        'childmenu' => 'required',
        'childmenu_hi' => 'required'

       ]);

    $save = new Childmenu;
    $save->submenu = $request->input('sub_menu');
    $save->mainmenu = $request->input('main_cat');
    $save->child_menu = $request->input('childmenu');
    $save->childmenu_hi = $request->input('childmenu_hi');
    $save->save();
    Submenu::where('sub_name',$request->input('sub_menu'))->where('cat_name',$request->input('main_cat'))->update(array('havechild' => 'Yes'));
    return redirect('admin-panel/addchildmenu')->with('status', 'Data Has been uploaded');

   }
public function uploadsitecontent(Request $request){
  
  	  $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
      $ip = $request->ip();
      $order = DB::table('action_logs')->insert([
          'ip_address' => $ip,
          'action_type' => 'Upload Sitecontent',
          'created_at' => now(),
          'updated_at' => now(),
          'created_by' => session('Loggeduser'),
          'updated_by' => session('Loggeduser'),
          'user_id' => session('Loggeduser'),
          'user_name' => $data['LoggeduserInfo']->username
      ]);
  
  
    if($request->con_type == 'Text'){
    $validatedData = $request->validate([
        'con_type' => 'required',
        'heading' => 'required',
        'image' => 'image|mimes:jpg,png,jpeg,gif,svg|max:8048',
        'main' => 'required',
        'content' => 'required',
        'language' => 'required',
       ]);
       $con_type = $request->input('con_type');
       $heading = $request->input('heading');
       $main_cat = $request->input('main');
       $language = $request->input('language');
       $sub_cat = $request->input('sub');
       $child_cat = $request->input('child');
       $content = $request->input('content');
           if ($request->hasFile('image') && $request->file('image')->isValid()) {
            $imageName = time() . '.' . $request->image->extension();
            $request->image->move(public_path('uploads'), $imageName);
        }else{
               $imageName='';
       }

       $save = new Sitecontent;
       $save->heading = $heading;
       $save->main_cat = $main_cat;
       $save->sub_cat = $sub_cat;
       $save->con_type = $con_type;
       $save->child_cat = $child_cat;
       $save->content = $content;
       $save->image = $imageName;
       $save->language = $language;
       $save->save();

       return redirect('admin-panel/addcontent')->with('status', 'Content Has been uploaded');
    }else{
        $validatedData = $request->validate([
            'con_type' => 'required',
            'heading' => 'required',
            'image' => 'required|mimes:pdf|mimetypes:application/pdf|max:55000',
            'main' => 'required',
			'language' => 'required',

           ]);
           $con_type = $request->input('con_type');
           $heading = $request->input('heading');
		   $language = $request->input('language');
           $main_cat = $request->input('main');
           $sub_cat = $request->input('sub');
           $child_cat = $request->input('child');

          
           $bl_file = time().".pdf";
           $destinationPath = public_path('uploads');
           if (!file_exists($destinationPath)) {
            mkdir($destinationPath, 0777, true);
           }
           $request->file('image')->move(
            $destinationPath.'/', $bl_file
           );


           $save = new Sitecontent;
           $save->heading = $heading;
           $save->main_cat = $main_cat;
           $save->sub_cat = $sub_cat;
           $save->con_type = $con_type;
           $save->child_cat = $child_cat;
		   $save->language = $language;
           $save->image = $bl_file;
           $save->save();

           return redirect('admin-panel/addcontent')->with('status', 'Content Has been uploaded');
    }
   }
   
   
public function updatesitecontent(Request $request){
    $validatedData = $request->validate([
        'heading' => 'required',
        'main' => 'required',
       ]);

	$data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
      $ip = $request->ip();
      $order = DB::table('action_logs')->insert([
          'ip_address' => $ip,
          'action_type' => 'Update Sitecontent',
          'created_at' => now(),
          'updated_at' => now(),
          'created_by' => session('Loggeduser'),
          'updated_by' => session('Loggeduser'),
          'user_id' => session('Loggeduser'),
          'user_name' => $data['LoggeduserInfo']->username
      ]);


       if(!empty($request->image)){
       $heading = $request->input('heading');
       $main_cat = $request->input('main');
       $sub_cat = $request->input('sub');
       $content = $request->input('content');
       $imageName = time().'.'.$request->image->extension();
       $request->image->move(public_path('uploads'), $imageName);

       $vij = Sitecontent::where('id',$request->id)->update(array('heading'=>$heading, 'image'=>$imageName, 'main_cat'=>$main_cat, 'sub_cat'=>$sub_cat, 'content'=>$content));
       if($vij){

       return redirect('admin-panel/managesitecontent')->with('status', 'Content Has been updated');
       }else{
       return redirect('admin-panel/managesitecontent')->with('status', 'Content Has not been updated');
       }
       }else{
       $heading = $request->input('heading');
       $main_cat = $request->input('main');
       $sub_cat = $request->input('sub');
       $content = $request->input('content');

       $vij = Sitecontent::where('id',$request->id)->update(array('heading'=>$heading, 'main_cat'=>$main_cat, 'sub_cat'=>$sub_cat, 'content'=>$content));
         if($vij){
       return redirect('admin-panel/managesitecontent')->with('status', 'Content Has been updated');
         }else{
         return redirect('admin-panel/managesitecontent')->with('fail', 'Content Has not been updated');
         }
       }

   }
   
 public function subcatfetch($id){
    $data = Submenu::where('cat_name',$id)->where('isDeleted','N')->get();


    return response()->json($data);
}
public function childcatfetch($id){
    $dataa = Childmenu::where('submenu',$id)->where('isDeleted','N')->get();
    return response()->json($dataa);
}

public function uploadgallery(Request $request){
    $validatedData = $request->validate([
        'image' => 'required|image|mimes:jpg,png,jpeg,gif,svg|max:2048',
        'category' => 'required'
       ]);

       $title = $request->input('heading');
       $imageName = time().'.'.$request->image->extension();
       $request->image->move(public_path('uploads'), $imageName);

       $save = new Photo;
       $save->title = $title;
       $save->title_hi = $request->heading_hi;
       $save->category = $request->category;
       $save->image = $imageName;
       $save->save();

       return redirect('admin-panel/gallery')->with('status', 'Image Has been uploaded');
}
public function uploadvideo(Request $request){
    $validatedData = $request->validate([
        'link' => 'required',
        'heading' => 'required',
        'heading_hi' => 'required'

       ]);

       $title = $request->input('link');
       $heading = $request->input('heading');
       $heading_hi = $request->input('heading_hi');
       $data = array(
           'video_link' => $title,
           'heading' => $heading,
           'heading_hi' => $heading_hi,
           'created_at' => date('Y-m-d'),
           );
       DB::table('videos')->insert($data);

       return redirect('admin-panel/videos')->with('status', 'Video Has been uploaded');
}



public function category(){
    $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
    $category = DB::table('image_category')->where('isDeleted', 'N')->orderBy('id', 'desc')->get();
    return view('admin.category', $data)->with('category', $category);
}

public function addCategory(Request $request){
    $validatedData = $request->validate([
        'category' => 'required',
        'category_hi' => 'required'
       ]);
  
	  $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
      $ip = $request->ip();
      $order = DB::table('action_logs')->insert([
          'ip_address' => $ip,
          'action_type' => 'Image Category',
          'created_at' => now(),
          'updated_at' => now(),
          'created_by' => session('Loggeduser'),
          'user_id' => session('Loggeduser'),
          'user_name' => $data['LoggeduserInfo']->username
      ]);

  
       $save = new Image_category;
       $save->name = $request->category;
       $save->name_hi = $request->category_hi;
       $save->save();
       return redirect('admin-panel/category')->with('status', 'Category Has been uploaded');
}


public function update_category(Request $request){
    $validatedData = $request->validate([
        'category' => 'required',
        'category_hi' => 'required'
       ]);

	  $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
      $ip = $request->ip();
      $order = DB::table('action_logs')->insert([
          'ip_address' => $ip,
          'action_type' => 'Image Category',
          'created_at' => now(),
          'updated_at' => now(),
          'updated_by' => session('Loggeduser'),
          'user_id' => session('Loggeduser'),
          'user_name' => $data['LoggeduserInfo']->username
      ]);

       $save =Image_category::where('id', $request->user_id)->first();
       $save->name = $request->category;
       $save->name_hi = $request->category_hi;
       $save->save();
       return redirect('admin-panel/category')->with('status', 'Category Has been Updated');
}



public function delete_category($id){
       $save =Image_category::where('id', $id)->first();
       $save->isDeleted = 'Y';
       $save->save();
       return redirect('admin-panel/category')->with('status', 'Category Has been Deleted');
}
}
