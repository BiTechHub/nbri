<?php

namespace App\Http\Controllers;
use App\Models\Admin;
use App\Models\Photo;
use App\Models\Contact;
use App\Models\Slider;
use App\Models\Teacher;
use App\Models\Submenu;
use App\Models\Sitecontent;
use App\Models\Childmenu;
use App\Models\Appointment;
use App\Models\Order_master;
use App\Models\Top_content;
use App\Models\News_master;
use App\Models\Tender_master;
use App\Models\DirectoryMaster;
use App\Models\Menu;
use Illuminate\Http\Request;
use DB;
use Session;
use Redirect;
use Validator;

class AdminControllers extends Controller
{
    public function index(){

        return view('admin.index');
    }

    public function check(Request $request){
    $request->validate([
        'username' => 'required',
        'password' => 'required|min:5|max:12',
        'captcha' => 'required',

    ]);
    $password = sha1($request->password);
      //dd($password);
    $userInfo = DB::table('admins')->where('username','=',$request->username)->first();

        if(!$userInfo){
            return redirect()->back()->with('status','we do not recognise your username !');
        }
        else{
            if($password == $userInfo->password){
                $request->session()->put('Loggeduser', $userInfo->id);
                return redirect('admin-panel/dashboard');
            }else{
                return redirect()->back()->with('status','Incorrect Password !');
            }
        }
    }
    public function reloadCaptcha()
    {
        return response()->json(['captcha'=> captcha_img()]);
    }
    public function admindash(){

        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        return view('admin.dashboard', $data);
    }
    public function logout(){
        if(session()->has('Loggeduser')){
            session()->pull('Loggeduser');
            return redirect('admin-panel');
        }
    }
    public function slider(){

        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        $ruchi = Slider::where('isDeleted','N')->orderBy('id', 'desc')->get();

        return view('admin.slider', $data)->with('ruchi',$ruchi);
    }
    public function officers(){

        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        $ruchi = Appointment::where('isDeleted','N')->orderBy('id', 'desc')->get();

        return view('admin.officers', $data)->with('ruchi',$ruchi);
    }
    public function gallery(){
        $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
        $photos = DB::table('photos')->orderBy('id', 'desc')->get();
        $category = DB::table('image_category')->where('isDeleted', 'N')->orderBy('id', 'desc')->get();
        return view('admin.gallery', $data)->with('photos', $photos)->with('category', $category);
    }
    
    public function videos(){

        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        $vijay = ['me'=>DB::table('videos')->where('isDeleted','N')->orderBy('id', 'desc')->get()];

        return view('admin.video', $data, $vijay);
    }
  public function addcontent(){

        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        $vijay = ['me'=>Submenu::orderBy('id', 'desc')->get()];
        $swt = Menu::where('isDeleted','N')->get();
        $swtt = Submenu::where('isDeleted','N')->get();
        return view('admin.addcontent', $data, $vijay)->with('swt',$swt)->with('swtt',$swtt);
    }
  public function managesitecontent(){

        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        $vijay = ['me'=>Submenu::orderBy('id', 'desc')->get()];
        $swt = Submenu::select('cat_name')->groupBy('cat_name')->where('isDeleted','N')->get();
        $swtt = Submenu::where('isDeleted','N')->get();
        $scontent = Sitecontent::where('isDeleted','N')->where('con_type','Text')->orderBy('created_at','desc')->get();
        $scontents = Sitecontent::where('isDeleted','N')->where('con_type','Pdf')->orderBy('created_at','desc')->get();
        return view('admin.managecontent', $data, $vijay)->with('swt',$swt)->with('swtt',$swtt)->with('scontents',$scontents)->with('scontent',$scontent);
    }
  public function editsitecontent($id){

        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        $vijay = ['me'=>Submenu::orderBy('id', 'desc')->get()];
        $swt = Menu::where('isDeleted','N')->get();
        $swtt = Submenu::where('isDeleted','N')->get();
        $scontent = Sitecontent::where('isDeleted','N')->where('id',$id)->first();
        return view('admin.editscontent', $data, $vijay)->with('swt',$swt)->with('swtt',$swtt)->with('scontent',$scontent);
    }
    public function contact(){

        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        //$vijay = Contact::orderBy('id', 'desc')->get();
		$vijay = DB::table('feedbacks')->orderBy('id', 'desc')->get();
      
        return view('admin.contact', $data)->with('ruchi',$vijay);
    }
    public function teachers(){

        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        $vijay = Teacher::where('isDeleted','N')->orderBy('id', 'desc')->get();

        return view('admin.teachers', $data)->with('ruchi',$vijay);
    }
  public function submenu(){

        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        $vijay = Submenu::where('isDeleted','N')->orderBy('id', 'desc')->get();
        $minu = Menu::where('isDeleted','N')->orderBy('id')->get();

        return view('admin.addsubmenu', $data)->with('ruchi',$vijay)->with('minu',$minu);
    }
    public function getSubmenu($cat){

        $data = Submenu::where('cat_name',$cat)->where('isDeleted','N')->pluck('sub_name');
        return response()->json($data);
    }
    public function addchildmenu(){

        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        $vijay = Childmenu::where('isDeleted','N')->orderBy('id')->get();
        $minu = Menu::where('isDeleted','N')->orderBy('id')->get();

        return view('admin.addchildmenu', $data)->with('minu',$minu)->with('ruchi',$vijay);
    }
    public function addmenu(){

        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        $vijay = Menu::where('isDeleted','N')->orderBy('id', 'desc')->get();

        return view('admin.addmenu', $data)->with('ruchi',$vijay);
    }
    public function delgallery($id){
        $imagem = Photo::where('id', $id)->first();
        $res = Photo::where('id', $id)->delete();
        if($res){
        unlink("uploads/".$imagem->image);
        return back()->with('success','Picture Deleted Successfully.');
        }else{
            return back()->with('fail','Picture Not Deleted Successfully.');

        }
    }
    public function delslider($id){
        $imagem = Slider::where('id', $id)->update(array('isDeleted'=>'Y'));

        if($imagem){

        return back()->with('success','Picture Deleted Successfully.');
        }else{
            return back()->with('fail','Picture Not Deleted Successfully.');

        }
    }
    public function delofficers($id){
        $imagem = Appointment::where('id', $id)->update(array('isDeleted'=>'Y'));

        if($imagem){

        return back()->with('success','Content Deleted Successfully.');
        }else{
            return back()->with('fail','Content Not Deleted Successfully.');

        }
    }
  public function delsitecontent($id){
        $imagem = Sitecontent::where('id', $id)->update(array('isDeleted'=>'Y'));

        if($imagem){

        return back()->with('success','Content Deleted Successfully.');
        }else{
            return back()->with('fail','Content Not Deleted Successfully.');

        }
    }
    public function delchildmenu($id){
        $imagem = Childmenu::where('id', $id)->update(array('isDeleted'=>'Y'));

        if($imagem){

        return back()->with('success','Content Deleted Successfully.');
        }else{
            return back()->with('fail','Content Not Deleted Successfully.');

        }
    }
    public function delappoint($id){
        //$imagem = Contact::where('id', $id)->delete();
      	  $imagem = DB::table('feedbacks')->where('id', $id)->delete();
        if($imagem){

        return back()->with('success','Message Deleted Successfully.');
        }else{
            return back()->with('fail','Message Not Deleted Successfully.');

        }
    }
    public function delteacher($id){
        $imagem = Teacher::where('id', $id)->update(array('isDeleted'=>'Y'));

        if($imagem){

        return back()->with('success','Data Deleted Successfully.');
        }else{
            return back()->with('fail','Data Not Deleted Successfully.');

        }
    }
  public function delsubmenu($id){
        $imagem = Submenu::where('id', $id)->update(array('isDeleted'=>'Y'));

        if($imagem){

        return back()->with('success','Data Deleted Successfully.');
        }else{
            return back()->with('fail','Data Not Deleted Successfully.');

        }
    }
    public function delmenu($id){
        $imagem = Menu::where('id', $id)->update(array('isDeleted'=>'Y'));

        if($imagem){

        return back()->with('success','Data Deleted Successfully.');
        }else{
            return back()->with('fail','Data Not Deleted Successfully.');

        }
    }
    public function delvideo($id){
        $imagem = DB::table('videos')->where('id', $id)->update(array('isDeleted'=>'Y'));

        if($imagem){

        return back()->with('success','Data Deleted Successfully.');
        }else{
            return back()->with('fail','Data Not Deleted Successfully.');

        }
    }
  
  public function read_language($id)
    {
        $category = DB::table('directory_category_master')
            ->where('language', $id)
            ->get();
            return response()->json($category);
    }
  
  public function phone_directory()
    {
        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
    	$category_master = DB::table('directory_category_master')->where('language', 'English')->get();
    	$category_hii = DB::table('directory_category_master')->where('language', 'Hindi')->get();
    	$directory = DB::table('directory_master')->orderBy('id', 'desc')->get();
        return view('admin.phone-directory', $data)->with('directory', $directory)->with('category_hii', $category_hii)->with('category_master', $category_master);
    }

  public function phone_directory_search($id)
    {
    	$category_id = DB::table('directory_category_master')->where('id', $id)->where('language', 'English')->first();
        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
    	$category_master = DB::table('directory_category_master')->where('language', 'English')->get();
    	$category_hii = DB::table('directory_category_master')->where('language', 'Hindi')->get();
    	$directory = DB::table('directory_master')->where('category', $id)->orderBy('id', 'desc')->get();
        return view('admin.phone-directory', $data)->with('category_id', $category_id)->with('directory', $directory)->with('category_hii', $category_hii)->with('category_master', $category_master);
    }
  
    public function office_orders()
    {
        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        return view('admin.office_orders', $data);
    }
    public function office_orders_list(){
        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        $order = DB::table('order_master')->orderBy('id', 'desc')->get();
        return view('admin.office_orders_list', $data)->with('order',$order);
    }

    public function addorders(Request $request) {
    // Validate incoming request data
    $validatedData = $request->validate([
        'order_no' => 'required',
        'subject' => 'required',
        'subject_hi' => 'required',
        'order_date' => 'required',
        'file' => 'required|mimes:pdf|max:8048'
    ]);

    // Get logged in user info
    $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
    $ip = $request->ip();

    // Insert action log
    DB::table('action_logs')->insert([
        'ip_address' => $ip,
        'action_type' => 'Update Sitecontent',
        'created_at' => now(),
        'updated_at' => now(),
        'created_by' => session('Loggeduser'),
        'updated_by' => session('Loggeduser'),
        'user_id' => session('Loggeduser'),
        'user_name' => $data['LoggeduserInfo']->username
    ]);

    // Check if file upload is valid
    if ($request->file('file')->isValid()) {
        $file = $request->file('file');
        $extension = $file->getClientOriginalExtension();
        $imageName = 'office-order-' . time() . '.' . $extension;
        $file->move(public_path('uploads/office_order/'), $imageName);
    } else {
        return redirect()->back()->withInput()->withErrors(['file' => 'File upload failed']);
    }

    // Save orders
    if ($request->subject) {
        $order = new Order_master;
        $order->order_no = $request->order_no;
        $order->category = $request->category;
        $order->language = 'English';
        $order->status = 1;
        $order->subject = $request->subject;
        $order->order_date = $request->order_date;
        $order->file_name = $imageName; // Assuming $imageName is accessible here
        $order->save();
    }

    if ($request->subject_hi) {
        $order2 = new Order_master;
        $order2->order_no = $request->order_no;
        $order2->language = 'Hindi';
        $order2->category = $request->category;
        $order2->status = 1;
        $order2->subject = $request->subject_hi;
        $order2->order_date = $request->order_date;
        $order2->file_name = $imageName; // Assuming $imageName is accessible here
        $order2->save();
    }

    return redirect('admin-panel/office_orders')->with('status', 'Data Has been uploaded');
}


    public function order_edit($id)
    {
        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        $order = DB::table('order_master')->where('id', $id)->first();
        return view('admin.order_edit', $data)->with('order', $order);
    }

   public function ordersedit(Request $request)
{
    $validatedData = $request->validate([
        'order_no' => 'required',
        'subject' => 'required',
        'order_date' => 'required',
        'file' => 'nullable|mimes:pdf|max:2048', // Adjust maximum file size as needed
    ]);

    // Fetch logged-in user info
    $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
    $ip = $request->ip();

    // Insert action log
    DB::table('action_logs')->insert([
        'ip_address' => $ip,
        'action_type' => 'Update Office Orders',
        'created_at' => now(),
        'updated_at' => now(),
        'created_by' => session('Loggeduser'),
        'updated_by' => session('Loggeduser'),
        'user_id' => session('Loggeduser'),
        'user_name' => $data['LoggeduserInfo']->username
    ]);

    // Find the order by ID
    $order = Order_master::find($request->id);
    if (!$order) {
        return redirect()->back()->with('error', 'Order not found');
    }

    // Update order fields
    $order->order_no = $request->order_no;
    $order->category = $request->category; // Make sure 'category' is coming from your form
    $order->subject = $request->subject;
    $order->order_date = $request->order_date;

    // Handle file upload
    if ($request->file('file')) {
        $file = $request->file('file');

        // Validate file
        if ($file->isValid()) {
            $extension = $file->getClientOriginalExtension();
            $imageName = 'office-order-' . time() . '.' . $extension;
            $file->move(public_path('uploads/office_order/'), $imageName);
            $order->file_name = $imageName;
        } else {
            return redirect()->back()->withInput()->withErrors(['file' => 'File upload failed']);
        }
    }

    // Save the order
    $order->save();

    return redirect('admin-panel/office_orders_list')->with('status', 'Data has been updated');
}



    public function topcontent()
    {
        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        $content = DB::table('top_content')->where('isDeleted', 'N')->orderBy('id', 'desc')->get(); 
        return view('admin.topcontent', $data)->with('content', $content);
    }

    public function uploadtopcontent(Request $request){
        $validatedData = $request->validate([
            'con_type' => 'required',
            'position' => 'required',
            'heading' => 'required',
			'heading_hi' => 'required',
            'file' => 'nullable|mimes:pdf',
            'file_hi' => 'nullable|mimes:pdf',
        ]);
      
    $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
          $ip = $request->ip();
          $order = DB::table('action_logs')->insert([
              'ip_address' => $ip,
              'action_type' => 'Upload Top Content',
              'created_at' => now(),
              'updated_at' => now(),
              'created_by' => session('Loggeduser'),
              'updated_by' => session('Loggeduser'),
              'user_id' => session('Loggeduser'),
              'user_name' => $data['LoggeduserInfo']->username
          ]);
      
      
        $order = New Top_content;
        $order->con_type = $request->con_type;
         $order->position = $request->position;
        $order->heading = $request->heading;
      	$order->text_color = $request->text_color;
      	$order->background_color = $request->background_color;
		$order->heading_hi = $request->heading_hi;
      	$order->effect = $request->effect;
        $order->link = $request->link;
        if ($request->file) {
            $image = $request->file;
            $extension = $image->getClientOriginalExtension();
            $imageName = time() . '.' . $extension;
            $image->move(public_path('uploads/'), $imageName);
            $order->file = $imageName;
        }
		if ($request->file_hi) {
            $imagehi = $request->file_hi;
            $extensionhi = $imagehi->getClientOriginalExtension();
            $imageNamehi = time() . '.' . $extensionhi;
            $imagehi->move(public_path('uploads/'), $imageNamehi);
            $order->file_hi = $imageNamehi;
        }
        $order->save();
        return redirect('admin-panel/topcontent')->with('status', 'Data has been uploaded');
    }

    public function topcondel($id){
        $imagem = Top_content::where('id', $id)->update(array('isDeleted'=>'Y'));
        if($imagem){
        return back()->with('success','Content Deleted Successfully.');
        }else{
            return back()->with('fail','Content Not Deleted Successfully.');
        }
    }

 public function topcontentedit($id){
        $content = Top_content::where('id', $id)->where('isDeleted', 'N')->first();
        
        if($content){
            $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
            return view('admin.topcontentedit', $data)->with('content', $content);
        }else{
            return back()->with('fail','Content Not found !.');
        }
    }



    public function add_news()
    {
        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        $section_master = DB::table('section_master')->get(); 
        return view('admin.addnews', $data)->with('section_master', $section_master);
    }
  
  
    public function newsadd(Request $request){
        $validatedData = $request->validate([
            'subject_hi' => 'required',
            'subject' => 'required',
            'section' => 'required',
            'document_language' => 'required',
            'news_date' => 'required',
            'file_name' => 'required|mimes:pdf|max:8048'
           ]);

      	$data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
          $ip = $request->ip();
          $order = DB::table('action_logs')->insert([
              'ip_address' => $ip,
              'action_type' => 'News Add',
              'created_at' => now(),
              'updated_at' => now(),
              'created_by' => session('Loggeduser'),
              'updated_by' => session('Loggeduser'),
              'user_id' => session('Loggeduser'),
              'user_name' => $data['LoggeduserInfo']->username
          ]);
      
      
      
      	  $image = $request->file_name;
           $extenstion = $image->getClientOriginalExtension();
           $imageName = time().'.'.$extenstion;
           $image->move('uploads/', $imageName);
      
      if($request->subject){
           $News = new News_master;
           $News->section = $request->section;
           $News->document_language = $request->document_language;
           $News->language = 'English';
           $News->status = 1;
           $News->subject = $request->subject;
           $News->news_date = $request->news_date;
           $News->file_name = $imageName;
           $News->save();
      }
      
      if($request->subject_hi){
           $News = new News_master;
           $News->section = $request->section;
           $News->document_language = $request->document_language;
           $News->language = 'Hindi';
           $News->status = 1;
           $News->subject = $request->subject_hi;
           $News->news_date = $request->news_date;
           $News->file_name = $imageName;
           $News->save();
      
      }
           return redirect('admin-panel/add-news')->with('status', 'Data Has been uploaded');
       }
  
  
  
       public function news_list(){
        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        $section = DB::table('section_master')
                    ->get();
        $news = DB::table('news_master')
            ->where('status', '1')
            ->orderBy('id', 'desc')
            ->paginate(20);
        return view('admin.news_list', $data)->with('news',$news)->with('section',$section);
    }

    public function newsdelete($id){
        $imagem = News_master::where('id', $id)->update(array('status'=>'0'));
        if($imagem){
        return back()->with('success','Content Deleted Successfully.');
        }else{
            return back()->with('fail','Content Not Deleted Successfully.');
        }
    }
  
  public function addTender()
    {
        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        $department_master = DB::table('department_master')
          		->get(); 
    $category_master = DB::table('category_master')
          		->orderBy('name', 'asc')
          		->get(); 
        return view('admin.addTender', $data)
          		->with('department_master', $department_master)
          		->with('category_master', $category_master);
    }
  
  public function add_tender(Request $request){
        $validatedData = $request->validate([
            'tender_no' => 'required',
            'opening_date' => 'required',
            'category' => 'required',
            'file' => 'mimes:pdf,zip,doc,docx,xls,xlsx|max:55048',
           ]);

    $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
          $ip = $request->ip();
          $order = DB::table('action_logs')->insert([
              'ip_address' => $ip,
              'action_type' => 'Add Tender',
              'created_at' => now(),
              'updated_at' => now(),
              'created_by' => session('Loggeduser'),
              'updated_by' => session('Loggeduser'),
              'user_id' => session('Loggeduser'),
              'user_name' => $data['LoggeduserInfo']->username
          ]);
    
           $News = new Tender_master;
           $News->tender_no = $request->tender_no;
           $News->department = $request->department;
           $News->language = 'English';
           $News->status = 1;
           $News->name_of_material = $request->name_of_material;
           $News->start_date = $request->start_date;
           $News->start_time = $request->start_time;
           $News->last_date = $request->last_date;
           $News->last_time = $request->last_time;
 		   $News->opening_date = $request->opening_date;
           $News->opening_time = $request->opening_time;
           $News->category = $request->category;

           $image = $request->file;
           $destinationPath = public_path('uploads/tender');
           $extenstion = $image->getClientOriginalExtension();
           $imageName = 'Tenders-Notice-' . time() . '.' . $extenstion; 
           if (!file_exists($destinationPath)) {
                mkdir($destinationPath, 0777, true);
            }
            $request->file('file')->move(
                $destinationPath.'/', $imageName
            );
          //$image->move($destinationPath.'/', $imageName);
           $News->file = $imageName;
    
           $News->save();
           return redirect('admin-panel/addTender')->with('status', 'Data Has been uploaded');

       }
  
    public function currentTenders()
     {
      $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
      $department_master = DB::table('department_master')
                  ->get(); 
      $category_master = DB::table('category_master')
                  ->orderBy('name', 'asc')
                  ->get(); 
      $tender_master = DB::table('tender_master')
                  ->orderBy('id', 'desc')
                  ->where('opening_date', '>=', date('Y-m-d'))
                  ->get();

          return view('admin.currentTenders', $data)
                  ->with('department_master', $department_master)
                  ->with('category_master', $category_master)
            	  ->with('tender_master', $tender_master);
      }
  	public function edit_tender($id)
    {
        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
      
        $tender_master = DB::table('tender_master')
            ->where('id', $id)
            ->first();
      $department_master = DB::table('department_master')
                  ->get(); 
      $category_master = DB::table('category_master')
                  ->orderBy('name', 'asc')
                  ->get(); 
        return view('admin.edit_tender', $data)
          			->with('department_master', $department_master)
            	    ->with('category_master', $category_master)
          			->with('tender_master',$tender_master);

    }
  
 public function EditTender(Request $request){
    // Validate the incoming request data
    $validatedData = $request->validate([
        'tender_no' => 'required',
        'opening_date' => 'required',
        'category' => 'required',
        'file' => 'mimes:pdf,zip,doc,docx,xls,xlsx|max:55048',
    ]);

    // Log the action
    $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
    $ip = $request->ip();
    DB::table('action_logs')->insert([
        'ip_address' => $ip,
        'action_type' => 'Update Tender',
        'created_at' => now(),
        'updated_at' => now(),
        'created_by' => session('Loggeduser'),
        'updated_by' => session('Loggeduser'),
        'user_id' => session('Loggeduser'),
        'user_name' => $data['LoggeduserInfo']->username
    ]);

    // Find the tender to update
    $tender = Tender_master::find($request->id);
    $tender->tender_no = $request->tender_no;
    $tender->department = $request->department;
    $tender->name_of_material = $request->name_of_material;
    $tender->start_date = $request->start_date;
    $tender->start_time = $request->start_time;
    $tender->last_date = $request->last_date;
    $tender->last_time = $request->last_time;
    $tender->opening_date = $request->opening_date;
    $tender->opening_time = $request->opening_time;
    $tender->category = $request->category;

    // Handle file upload
    if ($request->hasFile('file')) {
        $file = $request->file('file'); 
        $extension = $file->getClientOriginalExtension(); 
        $fileName = 'Tenders-Notice-' . time() . '.' . $extension; 
       
           $destinationPath = public_path('uploads/tender');
          
           if (!file_exists($destinationPath)) {
                mkdir($destinationPath, 0777, true);
            }
            $request->file('file')->move(
                $destinationPath.'/', $fileName
            );
        $tender->file = $fileName; 
    }

    // Save the updated tender
    $tender->save();

    // Redirect to the current tenders page with a success message
    return redirect('admin-panel/currentTenders')->with('status', 'Data has been uploaded');
}

  
  public function archiveTenders()
     {
      $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
      $department_master = DB::table('department_master')
                  ->get(); 
      $category_master = DB::table('category_master')
                  ->orderBy('name', 'asc')
                  ->get(); 
      $tender_master = DB::table('tender_master')
                  ->orderBy('id', 'desc')
                  ->where('opening_date', '<', date('Y-m-d'))
                  ->get();

          return view('admin.archiveTenders', $data)
                  ->with('department_master', $department_master)
                  ->with('category_master', $category_master)
            	  ->with('tender_master', $tender_master);
      }
  
  public function deactivate($id){
        $imagem = Tender_master::where('id', $id)->update(array('status'=>'0'));

        if($imagem){

        return back()->with('success','Data Deactivate Successfully.');
        }else{
            return back()->with('fail','Data Not Deactivate Successfully.');

        }
    }

  public function activate($id){
        $imagem = Tender_master::where('id', $id)->update(array('status'=>'1'));

        if($imagem){

        return back()->with('success','Data Activate Successfully.');
        }else{
            return back()->with('fail','Data Not Activate Successfully.');

        }
    }
  
  public function add_listing($id)
    {
        $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
        return view('admin.add_listing', $data);
    }
  
  public function view_listing($id)
  {
    $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
    $listing_master = DB::table('listing_master')
                  ->where('tender_id', $id)
                  ->get(); 
    return view('admin.view_listing', $data)->with('listing_master', $listing_master);
  }

  
   public function import(Request $request)
  {
      $request->validate([
          'category' => 'required',
          'category_hi' => 'required',
          'file' => 'required|mimes:csv,txt',
          'file_hi' => 'required|mimes:csv,txt',
      ]);

      	 $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
          $ip = $request->ip();
          $order = DB::table('action_logs')->insert([
              'ip_address' => $ip,
              'action_type' => 'Add Phone Directory',
              'created_at' => now(),
              'updated_at' => now(),
              'created_by' => session('Loggeduser'),
              'updated_by' => session('Loggeduser'),
              'user_id' => session('Loggeduser'),
              'user_name' => $data['LoggeduserInfo']->username
          ]);
     
      // English data
      $category = $request->category;
      $file = $request->file('file');
      $fileContents = file($file->getPathname());

      // Hindi data
      $category_hi = $request->category_hi;
      $file_hi = $request->file('file_hi');
      $fileContents_hi = file($file_hi->getPathname());

      $dataToInsert = [];

      // Process English data
      foreach ($fileContents as $line) {
          $data = str_getcsv($line);

          $dataToInsert[] = [
              'name' => $data[0],
              'designation' => $data[1],
              'area' => $data[2],
              'twitter' => $data[3],
              'email' => $data[4],
              'contact' => $data[5],
              'language' => 'English',
              'category' => $category,
          ];
      }

      // Process Hindi data
      foreach ($fileContents_hi as $line2) {
          $data2 = str_getcsv($line2);

          $dataToInsert[] = [
              'name' => $data2[0],
              'designation' => $data2[1],
              'area' => $data2[2],
              'twitter' => $data2[3],
              'email' => $data2[4],
              'contact' => $data2[5],
              'language' => 'Hindi',
              'category' => $category_hi,
          ];
      }

      // Insert all records at once
      DB::table('directory_master')->insert($dataToInsert);

      return redirect()->back()->with('success', 'CSV files imported successfully.');
  }

public function delete_phone_directory($id)
{
    DB::table('directory_master')->where('id', $id)->delete();
    return redirect()->back()->with('success', 'Deleting successfully.');
}

public function edit_phone_directory($id)
{
  $data = ['LoggeduserInfo'=>Admin::where('id','=',session('Loggeduser'))->first()];
  $category_master = DB::table('directory_category_master')->where('language', 'English')->get();
  $category_hii = DB::table('directory_category_master')->where('language', 'Hindi')->get();
  $directory_master = DB::table('directory_master')->where('id', $id)->first();
    return view('admin.edit-phone-directory', $data)->with('directory_master', $directory_master)->with('category_hii', $category_hii)->with('category_master', $category_master);
}
  
  
  public function update_directory(Request $request)
{
    
     $data = ['LoggeduserInfo' => Admin::where('id', '=', session('Loggeduser'))->first()];
          $ip = $request->ip();
          $order = DB::table('action_logs')->insert([
              'ip_address' => $ip,
              'action_type' => 'Update Phone Directory',
              'created_at' => now(),
              'updated_at' => now(),
              'created_by' => session('Loggeduser'),
              'updated_by' => session('Loggeduser'),
              'user_id' => session('Loggeduser'),
              'user_name' => $data['LoggeduserInfo']->username
          ]);
    
    
    
    $directory_master = DB::table('directory_master')->where('id', $request->id)->first();

    if ($directory_master) {
        $directory_master->category = $request->category;
        $directory_master->name = $request->name;
        $directory_master->designation = $request->designation;
        $directory_master->area = $request->area;
        $directory_master->twitter = $request->twitter;
        $directory_master->email = $request->email;
        $directory_master->contact = $request->contact;
        
        DB::table('directory_master')->where('id', $request->id)->update((array)$directory_master);

        return redirect('admin-panel/phone-directory')->with('status', 'Data has been updated');
    } else {
        return redirect()->back()->with('error', 'Record not found');
    }
}

  
  
  public function office_active($id){
        $imagem = DB::table('appointments')->where('id', $id)->update(array('status'=>'Deactivate'));

        if($imagem){

        return back()->with('success','Data Deactivate Successfully.');
        }else{
            return back()->with('fail','Data Not Deactivate Successfully.');

        }
    }

  public function office_deactivate($id){
        $imagem = DB::table('appointments')->where('id', $id)->update(array('status'=>'Active'));
        if($imagem){

        return back()->with('success','Data Activate Successfully.');
        }else{
            return back()->with('fail','Data Not Activate Successfully.');

        }
    }
  
  
  public function slider_active($id){
        $imagem = DB::table('sliders')->where('id', $id)->update(array('status'=>'Deactivate'));

        if($imagem){

        return back()->with('success','Data Deactivate Successfully.');
        }else{
            return back()->with('fail','Data Not Deactivate Successfully.');

        }
    }

  public function slider_deactivate($id){
        $imagem = DB::table('sliders')->where('id', $id)->update(array('status'=>'Active'));
        if($imagem){

        return back()->with('success','Data Activate Successfully.');
        }else{
            return back()->with('fail','Data Not Activate Successfully.');

        }
    }
  
    
}

