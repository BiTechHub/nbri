<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Slider;

use DB;

use App\Models\Feedback;

class HindiController extends Controller
{
    
    public function actsRules()
    {
        return view('hindi.Acts-Rules');
        
     }


     public function hindi()
     {
        $slider = Slider::where('status','Active')->where('isDeleted','N')->orderBy('id', 'desc')->get();
        $officer =DB::table('appointments')->where('status','Active')->where('isDeleted','N')->get();
        $content = DB::table('top_content')->where('isDeleted', 'N')->orderBy('id','desc')->get(); 
        $news_i = DB::table('news_master')
                ->where('status', '1')
                ->where('language', 'Hindi')
                ->where('section', '1')
                ->orderBy('created_at', 'desc')
                ->limit(3)
                ->get();
        $news_h = DB::table('news_master')
                ->where('status', '1')
                ->where('language', 'Hindi')
                ->where('section', '2')
                ->orderBy('created_at', 'desc')
                ->limit(3)
                ->get();
        $news_n = DB::table('news_master')
                ->where('status', '1')
                ->where('language', 'Hindi')
                ->where('section', '3')
                ->orderBy('created_at', 'desc')
                ->limit(3)
                ->get();
        $news = DB::table('news_master')
            ->where('status', '1')
            ->where('language', 'Hindi')
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();
        $latestPhotos = DB::table('photos')
            ->orderBy('id', 'desc')
            ->take(4)
            ->get();
        $latestVideo = DB::table('videos')
            ->orderBy('id', 'desc')
            ->first();
        

         return view('hindi.index')
                ->with('slider',$slider)
                ->with('officer',$officer)
                ->with('news_i',$news_i)
                ->with('news_h',$news_h)
                ->with('news_n',$news_n)
                ->with('news',$news)
                ->with('latestPhotos',$latestPhotos)
                ->with('latestVideo',$latestVideo)
                ->with('content',$content);
      }

  public function officeOrders()
  {
    $currentYear = now()->year;
    $order = DB::table('order_master')
      ->where('language', 'Hindi')
      ->whereYear('created_at', $currentYear)
      ->orderBy('id', 'desc')
      ->get();
    return view('hindi.office-orders')->with('order', $order);

  }
    public function officeOrdersArchive()
    {
      $currentYear = now()->year;

      $orders = DB::table('order_master')
        ->where('language', 'Hindi')
        ->whereYear('created_at', '<>', $currentYear)
        ->orderBy('id', 'desc')
        ->get();
      return view('hindi.office-orders-archive')->with('order', $orders);
    }

    public function gallery()
    {
        $imgcate ="स्वतंत्रता दिवस 15.08.2023";
        $photos = DB::table('photos')->where('category', 17)->orderBy('id', 'desc')->get();
        $category = DB::table('image_category')->orderBy('id', 'desc')->where('isDeleted', 'N')->get();
        return view('hindi.gallery')->with('photos', $photos)->with('category', $category)->with('imgcate', $imgcate);
     }

  public function img($id)
    {
    $photos = DB::table('photos')->where('category', $id)->orderBy('id', 'desc')->get();
     return response()->json($photos);
    }
  
  
    public function video()
    {
      $videos = DB::table('videos')->orderBy('id', 'desc')->get();
      return view('hindi.video')->with('videos', $videos);

    }

    public function submenuPage($menu, $submenu, $name = null)
    {
      
      $menu2 = DB::table('menus')->where('id', $menu)->where('isDeleted', 'N')->first()->menu_name ;
	  $submenu2 = DB::table('submenus')->where('id', $submenu)->where('isDeleted', 'N')->first()->sub_name ;
      
 	 $menus_h = DB::table('menus')
            ->where('id', $menu)
            ->first();
      $sub_menus = DB::table('submenus')
            ->where('id', $submenu)
            ->first();
       
      	$sitecontents = DB::table('sitecontents')
            ->where('main_cat', $menu)
            ->where('sub_cat', $submenu)
			->where('language', 'Hindi')
			->orderBy('id','desc')
            ->get();
        $directorymaster = DB::table('directory_master')
            ->where('language', 'Hindi')
            ->where('status', '1')
            ->orderBy('id', 'desc')
            ->get();
        $category = DB::table('directory_category_master')
            ->where('language', 'Hindi')
            ->get();

        return view('hindi.page')
            ->with('sitecontents', $sitecontents)
            ->with('directorymaster', $directorymaster)
            ->with('category', $category)
            ->with('submenu', $submenu2)
          	->with('sub_menus', $sub_menus)
            ->with('menus_h', $menus_h)
            ->with('menu', $menu2);
    }

    public function menuPage($menu, $name = null)
    {
        return view('hindi.page');
    }
    public function news_hi($id)
    {
        $section = DB::table('section_master')
                    ->where('id', $id)
                    ->first();
        $news = DB::table('news_master')
            ->where('status', '1')
            ->where('language', 'Hindi')
            ->where('section', $id)
            ->orderBy('id', 'desc')
            ->paginate(20);
        return view('hindi.news')->with('news',$news)->with('section',$section);
    }
  
  public function OrganisationStructure()
    {
        return view('hindi.Organisation-Structure');
    }
  public function electrical_accident()
    {
        return view('hindi.electrical-accident');
    }
  
  public function consumer_forms()
    {
        return view('hindi.consumer-forms');
    }
  
  public function read_data($id)
    {
    $result = DB::table('directory_master')
      ->where('category', $id)
      ->where('language', 'Hindi')
      ->where('status', '1')
      ->get();
    return response()->json($result);

    }
  
  
  
    public function copyright_policy()
    {
    
        return view('hindi.copyright-policy');
    }
  
  public function hyperlink_policy()
    {
    
        return view('hindi.hyperlink-policy');
    }
  
  public function privacy_policy()
    {
        return view('hindi.privacy-policy');
    }
  
  public function terms_condition()
    {
        return view('hindi.terms-condition');
    }
  
  public function security_policy()
    {
        return view('hindi.security-policy');
    }
  
  public function accessibility_statement()
    {
        return view('hindi.accessibility-statement');
    }
  
  public function disclaimer()
    {
        return view('hindi.disclaimer');
    }
  
 public function help()
    {
        return view('hindi.help');
    }
  
 public function screen_reader_access()
    {
        return view('hindi.screen-reader-access');
    }
  
   public function feedback()
    {
        return view('hindi.feedback');
    }
  
  
   public function sitemap()
    {
        return view('hindi.sitemap');
    }
  
  public function download_forms()
    {
        return view('hindi.download_forms');
    }
  
  public function faq()
    {
        return view('hindi.faq');
    }
  
public function bill_calculator()
    {
      	$lang='hindi';
        return view('frontend.bill-calculator')->with('lang',$lang);
    }
  
  
   public function about()
    {
        return view('hindi.about');
    }
  
  public function ImportantLink()
    {
    	$news_i = DB::table('news_master')
            ->where('status', '1')
            ->where('language', 'Hindi')
            ->where('section', '1')
            ->orderBy('created_at', 'desc')
            ->get();
        return view('frontend.ImportantLink')->with('news_i', $news_i);
    }
  public function Highlights()
    {
     	$news_h = DB::table('news_master')
            ->where('status', '1')
            ->where('language', 'Hindi')
            ->where('section', '2')
            ->orderBy('created_at', 'desc')
            ->get();
        return view('frontend.Highlights')->with('news_h', $news_h);
    }
  
  public function NewsNotifications()
    {
    	$news_n = DB::table('news_master')
            ->where('status', '1')
            ->where('language', 'Hindi')
            ->where('section', '3')
            ->orderBy('created_at', 'desc')
            ->get();
        return view('frontend.NewsNotifications')->with('news_n', $news_n);
    }
  
  
  public function tarrif_order()
    {
        return view('hindi.tarrif-order');
    }
  
  

}
