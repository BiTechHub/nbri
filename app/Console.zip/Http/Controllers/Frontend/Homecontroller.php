<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use App\Models\Slider;
use App\Models\Feedback;

class Homecontroller extends Controller
{
    public function home()
    {
    $slider = Slider::where('status','Active')->where('isDeleted','N')->orderBy('id', 'desc')->get();
    $officer =DB::table('appointments')->where('status','Active')->where('isDeleted','N')->get();
    $content = DB::table('top_content')->where('isDeleted', 'N')->orderBy('id','desc')->get(); 
    $news_i = DB::table('news_master')
            ->where('status', '1')
            ->where('language', 'English')
            ->where('section', '1')
            ->orderBy('created_at', 'desc')
            ->limit(3)
            ->get();
    $news_h = DB::table('news_master')
            ->where('status', '1')
            ->where('language', 'English')
            ->where('section', '2')
            ->orderBy('created_at', 'desc')
            ->limit(3)
            ->get();
    $news_n = DB::table('news_master')
            ->where('status', '1')
            ->where('language', 'English')
            ->where('section', '3')
            ->orderBy('created_at', 'desc')
            ->limit(3)
            ->get();
    $news = DB::table('news_master')
            ->where('status', '1')
            ->where('language', 'English')
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();
      
      $latestPhotos = DB::table('photos')
            ->orderBy('id', 'desc')
            ->take(4)
            ->get();
      $latestVideo = DB::table('videos')
            ->orderBy('id', 'desc')
            ->first();
      
      return view('frontend.index')
            ->with('slider',$slider)
            ->with('officer',$officer)
            ->with('news_i',$news_i)
            ->with('news_h',$news_h)
            ->with('news_n',$news_n)
            ->with('news',$news)
        	->with('latestPhotos',$latestPhotos)
            ->with('latestVideo',$latestVideo)
            ->with('content',$content);
    }

    public function index($cat)
    {
        
        $scontent=DB::table('budget')
                  ->where('category',$cat)
                  ->where('isDeleted','N')
                  ->orderBy('id','desc')
                  ->get();
        
        return view('frontend.site_content')->with('scontent',$scontent)->with('cat_name',$cat);
    }

    // introduction 
    public function Introduction()
    {
        return view('frontend.introduction');
    }

    // Technic 
    public function Technic()
    {
        return view('frontend.technic');
    }

    // qualitycontrol 
    public function qualitycontrol()
    {
        return view('frontend.quality_control');
    }

    // registeredproducers 
    public function registeredproducers()
    {
        $registerp=DB::table('location')
                   ->where('isDeleted','N')
                   ->orderBy('id','desc')
                   ->get();
        return view('frontend.registered_producers')->with('cat_name',$registerp);
    }



    // rabikharif 
    public function rabikharif($location_id)
    {
        $rabisterp=DB::table('course_type')
                ->where('isDeleted','N')
                ->get();
        return view('frontend.rabi_kharif')->with('rabisterp',$rabisterp)->with('location_id',$location_id);

    }

    // finalrabi 
    public function finalrabi(Request $request)
    {

        $rabggterp=DB::table('course')
                ->where('location_id',$request->location_id)
                ->where('course_type',$request->id)
                ->where('isDeleted','N')
                ->get();

        return view('frontend.final_rabi')->with('rabggterp',$rabggterp);
    }



         
    // formerdata 
    public function formerdata()
    {
        $registerp=DB::table('location')
                    ->where('isDeleted','N')
                    ->orderBy('id','desc')
                    ->get();
        return view('frontend.farmer-data')->with('cat_name',$registerp);
    }

    // rabikharif 
     public function getdata($location_id)
     {
         $rabisterp=DB::table('course_type')
                    ->where('isDeleted','N')
                    ->get();
         return view('frontend.farmerget-data')->with('rabisterp',$rabisterp)->with('location_id',$location_id);

     }


    // finalrabi 
    public function finalgetdata(Request $request)
    {

        $rabggterp=DB::table('farmerdata')
                    ->where('location_id',$request->location_id)
                    ->where('course_type',$request->id)
                    ->where('isDeleted','N')
                    ->get();

        return view('frontend.finalget-data')->with('rabggterp',$rabggterp);
    }

    // rolling 
    public function rolling()
    {
        return view('frontend.rolling_page');
            
    }


        // roll data  
    public function roll($dataname)
    {

        $radddbggterp=DB::table('seed_plan')
        ->where('cat',$dataname)
        ->orderBy('id','desc')
        ->get();

    return view('frontend.rolling_data')->with('rabdsggterp',$radddbggterp);
           
     }


    //  feedback  submit
    public function feedbacksubmit(Request $request)
    {
       $validatedData = $request->validate([
        'name' => 'required|string|max:255',
        'email' => 'required|email|max:255',
        'mobile' => 'required|string|max:20',
        'feedback' => 'required|string',
    ]);
        $data = new Feedback;
        $data->name = $request->name;
        $data->email = $request->email;
        $data->mobile = $request->mobile;
        $data->feedback = $request->feedback;
        $data->save();
        return redirect()->back()->with('message','Feedback Subbmited Successfully !'); 
    }


          
        //  feedback 
    public function links()
    {

        return view('frontend.links');
        
     }

    public function actsRules()
    {
        return view('frontend.page');
        
     }

    public function gallery()
    {
      	$imgcate ="Independence Day 15.08.2023";
        $photos = DB::table('photos')->where('category', 17)->orderBy('id', 'desc')->get();
        $category = DB::table('image_category')->where('isDeleted', 'N')->orderBy('id', 'desc')->where('isDeleted', 'N')->get();
        return view('frontend.gallery')->with('photos', $photos)->with('category', $category)->with('imgcate', $imgcate);
    }

  
   public function img($id)
    {
     	$photos = DB::table('photos')->where('category', $id)->orderBy('id', 'desc')->get();
        return response()->json($photos);
    }
  
  
     public function video()
     {
         $videos = DB::table('videos')->orderBy('id', 'desc')->get();
         return view('frontend.video')->with('videos', $videos);
         
      }

     //Hindi

     public function hindi()
     {
         return view('hindi.index');
         
      }


    public function submenuPage($menu, $submenu, $name = null)
    {
      
     
   		$menu2 = DB::table('menus')->where('id', $menu)->where('isDeleted', 'N')->first()->menu_name ;
		$submenu2 = DB::table('submenus')->where('id', $submenu)->where('isDeleted', 'N')->first()->sub_name ;
      
      $page_id = $menu2;
        $sitecontents = DB::table('sitecontents')
            ->where('main_cat', $menu)
            ->where('sub_cat', $submenu)
			->where('language', 'English')
          ->where('isDeleted', 'N')
			->orderBy('id','desc')
          
            ->get();
        $directorymaster = DB::table('directory_master')
            ->where('language', 'English')
            ->where('status', '1')
            ->orderBy('id', 'desc')
            ->get();
        $category = DB::table('directory_category_master')
            ->where('language', 'English')
            ->get();

        return view('frontend.page')
            ->with('sitecontents', $sitecontents)
            ->with('directorymaster', $directorymaster)
            ->with('category', $category)
            ->with('submenu', $submenu2)
          	->with('page_id', $page_id)
          	->with('main_cat', $menu)
            ->with('menu', $menu2);
    }

    public function menuPage($menu, $name = null)
    {
        $menu2 = DB::table('menus')->where('id', $menu)->where('isDeleted', 'N')->first()->menu_name ;
       $sitecontents = DB::table('sitecontents')
            ->where('main_cat', $menu)
            ->where('sub_cat', NULL)
            ->get();
        return view('frontend.page2')
                ->with('sitecontents', $sitecontents)
                ->with('menu2', $menu2)
                ->with('menu', $menu);
    }

    public function read_data($id)
    {
        $result = DB::table('directory_master')
            ->where('category', $id)
            ->where('language', 'English')
            ->where('status', '1')
          	->orderBy('id', 'asc')
            ->get();
        return response()->json($result);

    }
  
    public function officeOrders()
    {
        $currentYear = now()->year;
        $order = DB::table('order_master')
            ->where('language', 'English')
            ->whereYear('created_at', $currentYear)
            ->orderBy('id', 'desc')
            ->get();
        return view('frontend.office-orders')->with('order', $order);
            
    }
  
    public function officeOrdersArchive()
    {
      $currentYear = now()->year;
      $orders = DB::table('order_master')
        ->where('language', 'English')
        ->whereYear('created_at', '<>', $currentYear)
        ->orderBy('id', 'desc')
        ->get();
      return view('frontend.office-orders-archive')->with('order', $orders);
    }

    public function news($id)
    {
		$currentYear = now()->year;
        $section = DB::table('section_master')
                    ->where('id', $id)
                    ->first();
	if($id == 3){
        $news = DB::table('news_master')
            ->where('status', '1')
            ->where('language', 'English')
            ->where('section', $id)
			->whereYear('created_at', $currentYear)
            ->orderBy('id', 'desc')
            ->paginate(20);
	} else {
		 $news = DB::table('news_master')
            ->where('status', '1')
            ->where('language', 'English')
            ->where('section', $id)
            ->orderBy('id', 'desc')
            ->paginate(20);
	}
        return view('frontend.news')->with('news',$news)->with('section',$section);
    }

	public function news_archive()
    {
		$currentYear = now()->year;
        $section = DB::table('section_master')
                    ->where('id', 3)
                    ->first();
        $news = DB::table('news_master')
            ->where('status', '1')
            ->where('language', 'English')
            ->where('section', 3)
			->whereYear('created_at', '<>', $currentYear)
            ->orderBy('id', 'desc')
            ->paginate(20);
		$status = "Archive";
        return view('frontend.news')
			->with('news',$news)
			->with('status',$status)
			->with('section',$section);
    }
    public function OrganisationStructure()
    {
        return view('frontend.Organisation-Structure');
    }
  public function electrical_accident()
    {
        return view('frontend.electrical-accident');
    }
  
  public function consumer_forms()
    {
        return view('frontend.consumer-forms');
    }
  

  
  public function tenders_notice()
    {
    
    $department_master = DB::table('department_master')
                  ->get(); 
      $category_master = DB::table('category_master')
                  ->orderBy('name', 'asc')
                  ->get(); 
      $tender_master = DB::table('tender_master')
                  ->orderBy('id', 'desc')
                  ->where('opening_date', '>=', date('Y-m-d'))
                  ->get();

          return view('frontend.tenders-notice')
                  ->with('department_master', $department_master)
                  ->with('category_master', $category_master)
            	  ->with('tender_master', $tender_master);
    }

  public function tender_notice_archive()
    {
    
    $department_master = DB::table('department_master')
                  ->get(); 
    $category_master = DB::table('category_master')
      ->orderBy('name', 'asc')
                 	->get(); 
    $tender_master = DB::table('tender_master')
      ->orderBy('id', 'desc')
      ->where('opening_date', '<', date('Y-m-d'))
      ->get();

    return view('frontend.tender-notice-archive')
      ->with('department_master', $department_master)
      ->with('category_master', $category_master)
      ->with('tender_master', $tender_master);

    }
  
    
    
   public function bill_calculator()
    {
        return view('frontend.bill-calculator');
    }
  
  public function calculateBilling(Request $request)
{
    // dd($request->toArray()); // Uncomment for debugging purposes

    $request->validate([
        'tarrif' => 'required',
        'supply_type' => 'required',
        'from_date' => 'required|date',
        'to_date' => 'required|date',
        'load' => 'required|numeric',
        'current_month_reading' => 'required|numeric',
        'previous_month_reading' => 'required|numeric',
    ]);

    $tarrif = $request->tarrif;
    $supply_type = $request->supply_type;
    $from_date = $request->from_date;
    $to_date = $request->to_date;
    $load = $request->load;
    $current_month_reading = $request->current_month_reading;
    $previous_month_reading = $request->previous_month_reading;

    if ($tarrif == "LMV 1") {
        $supply_type = "ST10";
    } else {
        $supply_type = "ST20";
    }

    $from_date = explode("-", $from_date);
    $from_date = $from_date[2] . "-" . $from_date[1] . "-" . $from_date[0];
    $to_date = explode("-", $to_date);
    $to_date = $to_date[2] . "-" . $to_date[1] . "-" . $to_date[0];
    $ts1 = strtotime($from_date);
    $ts2 = strtotime($to_date);
    $year1 = date('Y', $ts1);
    $year2 = date('Y', $ts2);
    $month1 = date('m', $ts1);
    $month2 = date('m', $ts2);
    $total_month = (($year2 - $year1) * 12) + ($month2 - $month1);
    $total_unit = $current_month_reading - $previous_month_reading;

    $fixed_charge_val = 0;
    $ed_charge_val = 0;
    $slab = 0;

    if ($supply_type == "ST10") {
        if ($load <= 1 && $total_unit <= 100) {
            $slab = 3.00;
            $fixed_charge_val = 50;
            $ed_charge_val = 5;
        } else {
            if ($total_unit <= 150) {
                $slab = 5.50;
            } else if ($total_unit > 150 && $total_unit <= 300) {
                $slab = 6.00;
            } else if ($total_unit > 300 && $total_unit <= 500) {
                $slab = 6.50;
            } else if ($total_unit > 500) {
                $slab = 7.00;
            }
            $fixed_charge_val = 110;
            $ed_charge_val = 5;
        }
    }

    if ($supply_type == "ST20") {
        if ($total_unit <= 300) {
            $slab = 7.50;
        } else if ($total_unit > 300 && $total_unit <= 1000) {
            $slab = 8.40;
        } else if ($total_unit > 1000) {
            $slab = 8.75;
        }

        if ($load <= 2) {
            $fixed_charge_val = 330;
        } else if ($load > 2 && $load <= 4) {
            $fixed_charge_val = 390;
        } else if ($total_unit > 4) {
            $fixed_charge_val = 450;
        }

        $ed_charge_val = 7.50;
    }

    $total_fixed_charge = $fixed_charge_val * $load * $total_month;
    $total_energy_charge = $slab * $total_unit;
    $total_ed_charge = (($total_fixed_charge + $total_energy_charge) * $ed_charge_val) / 100;
    $total_rsc_charge = (($total_fixed_charge + $total_energy_charge) * 0) / 100;
    $total_charges = $total_fixed_charge + $total_energy_charge + $total_ed_charge + $total_rsc_charge;

    if ($from_date != "") {
        $from_date = explode("-", $from_date);
        $from_date = $from_date[2] . "-" . $from_date[1] . "-" . $from_date[0];
    }

    if ($to_date != "") {
        $to_date = explode("-", $to_date);
        $to_date = $to_date[2] . "-" . $to_date[1] . "-" . $to_date[0];
    }

    return redirect('bill-calculator')
      	->with('total_month', $total_month)
    	->with('total_unit', $total_unit)
      	->with('total_energy_charge', $total_energy_charge)
        ->with('total_fixed_charge', $total_fixed_charge)
        ->with('total_ed_charge', $total_ed_charge)
        ->with('total_rsc_charge', $total_rsc_charge)
        ->with('total_charges', $total_charges)
      	->with('previous_month_reading', $previous_month_reading)
    	->with('current_month_reading', $current_month_reading)
      	->with('load', $load)
        ->with('to_date', $to_date)
        ->with('from_date', $from_date)
        ->with('supply_type', $supply_type)
        ->with('tarrif', $tarrif);
}

  
  
  
  public function theftassessmentcalculator()
    {
    
        return view('frontend.theft-assessment-calculator');
    }
  
   public function assessment_calculator(Request $request)
    {
    
    //dd($request->toArray());
     
     $request->validate([
        'nirdharit_load' => 'required|numeric',
        'awadhi_mahino_mai' => 'required|numeric',
        'vidyut_aapurti' => 'required|numeric',
        'load_factor' => 'required',
        'area_type' => 'required', 
    ]);
     
     
     
       $nirdharit_load = $request->nirdharit_load;
       $awadhi_mahino_mai = $request->awadhi_mahino_mai;
       $vidyut_aapurti = $request->vidyut_aapurti;
       $load_factor = $request->load_factor;
       $area_type = $request->area_type;
     
     if($load_factor=="A")
    {
        $load_factor_val=0.30;
    }

    if($load_factor=="B")
    {
        $load_factor_val=0.50;
    }

    if($load_factor=="C")
    {
        $load_factor_val=0.50;
    }

    if($load_factor=="D")
    {
        $load_factor_val=0.75;
    }

    if($load_factor=="E")
    {
        $load_factor_val=0.30;
    }

    if($load_factor=="F")
    {
        $load_factor_val= 0.50;
    }

 $nirdharit_ikai=$nirdharit_load*$load_factor_val*($awadhi_mahino_mai*30)*$vidyut_aapurti;

    if($area_type=="Domestic")
    {
        if($nirdharit_ikai>(150*$awadhi_mahino_mai))
        {
            $slab1=150*5.5*$awadhi_mahino_mai;
        }
        else
        {
            $slab1=$nirdharit_ikai*5.5;
        }

        if($nirdharit_ikai>(300*$awadhi_mahino_mai))
        {
            $slab2=150*$awadhi_mahino_mai*6;
        }
        else
        {
            if($nirdharit_ikai>(150*$awadhi_mahino_mai))
            {
                $slab2=($nirdharit_ikai-(150*$awadhi_mahino_mai))*6;
            }
            else
            {
                $slab2=0;
            }
        }


        if($nirdharit_ikai>(500*$awadhi_mahino_mai))
        {
            $slab3=200*$awadhi_mahino_mai*6.5;
        }
        else
        {
            if($nirdharit_ikai>(300*$awadhi_mahino_mai))
            {
                $slab3=($nirdharit_ikai-(300*$awadhi_mahino_mai))*6.5;
            }
            else
            {
                $slab3=0;
            }
        }


        if($nirdharit_ikai>(500*$awadhi_mahino_mai))
        {
            $slab4=($nirdharit_ikai-(500*$awadhi_mahino_mai))*7;
        }
        else
        {
            $slab4=0;
        }
    }


    if($area_type=="Commercial")
    {
        if($nirdharit_ikai>(300*$awadhi_mahino_mai))
        {
            $slab1=300*7.5*$awadhi_mahino_mai;
        }
        else
        {
            $slab1=$nirdharit_ikai*7.5;
        }

        if($nirdharit_ikai>(1000*$awadhi_mahino_mai))
        {
            $slab2=700*$awadhi_mahino_mai*8.4;
        }
        else
        {
            if($nirdharit_ikai>(300*$awadhi_mahino_mai))
            {
                $slab2=($nirdharit_ikai-300)*8.4;
            }
            else
            {
                $slab2=0;
            }
        }


        if($nirdharit_ikai>(1000*$awadhi_mahino_mai))
        {
            $slab3=($nirdharit_ikai-(1000*$awadhi_mahino_mai))*8.75;
        }
        else
        {
            $slab3=0;
        }

        $slab4=0;
    }

    $slab5=$slab1+$slab2+$slab3+$slab4;
    $slab6=$slab5*2;
    $nirdharan_dhanrashi=$slab6*1.075;
     
    return redirect('theft-assessment-calculator')
    	->with('nirdharit_ikai', $nirdharit_ikai)
    	->with('nirdharan_dhanrashi', $nirdharan_dhanrashi)
      
      	->with('nirdharit_load', $nirdharit_load)
        ->with('awadhi_mahino_mai', $awadhi_mahino_mai)
        ->with('vidyut_aapurti', $vidyut_aapurti)
        ->with('load_factor', $load_factor)
        ->with('area_type', $area_type);


    }

  public function estimate_calculator()
    {
    
    $loadmaster = DB::table('load_range_master')
                  ->get(); 
    $areamaster = DB::table('area_type_master')
                  ->get(); 
    $linemaster = DB::table('line_installation_option_master')
                  ->get();
        return view('frontend.estimate-calculator')
          				->with('loadmaster', $loadmaster)
          				->with('areamaster', $areamaster)
          				->with('linemaster', $linemaster);
    }
  
  
  public function estimateCalculator(Request $request)
    {
        

    //dd($request->toArray());
    
       $load_range = $request->load_range;
       $length_of_overhead_line = $request->length_of_overhead_line;
       $length_of_underground_line = $request->length_of_underground_line;
       $line_installation_option = $request->line_installation_option;
       $area_type = $request->area_type;
    
    	$total_length_of_line=$length_of_overhead_line+$length_of_underground_line;
    
          
    
    $overhead_rate_sel = DB::table('rate_master')
      ->orderBy('id', 'desc')
      ->where('line_installation_id', $line_installation_option)
      ->where('area_id', $area_type)
      ->where('load_id', $load_range)
      ->where('category_id', '1')
      ->first();
    
    	$overhead_rate=$overhead_rate_sel->rate;
        $overhead_applicant_percentage=$overhead_rate_sel->applicant_percentage;
    
           
    
     $underground_rate_sel = DB::table('rate_master')
      ->orderBy('id', 'desc')
      ->where('line_installation_id', $line_installation_option)
      ->where('area_id', $area_type)
      ->where('load_id', $load_range)
      ->where('category_id', '2')
      ->first();
    
    $underground_rate = $underground_rate_sel->rate;
    $underground_applicant_percentage = $underground_rate_sel->applicant_percentage;
    
    $cost_of_overhead_line=$overhead_rate*$length_of_overhead_line;
    $cost_of_underground_line=$underground_rate*$length_of_underground_line;
    $total_estimate_licensee_exclusive_gst=$cost_of_overhead_line+$cost_of_underground_line;
    $gst=($total_estimate_licensee_exclusive_gst*18)/100;
    $total_estimate_licensee_inclusive_gst=$total_estimate_licensee_exclusive_gst+$gst;
    $total_estimate_applicant_exclusive_gst=($total_estimate_licensee_exclusive_gst*$underground_applicant_percentage)/100;
    $total_estimate_applicant_inclusive_gst=$gst+$total_estimate_applicant_exclusive_gst;

    
    return redirect('estimate-calculator')
    	->with('cost_of_overhead_line', $cost_of_overhead_line)
    	->with('cost_of_underground_line', $cost_of_underground_line)
      	->with('total_estimate_licensee_exclusive_gst', $total_estimate_licensee_exclusive_gst)
        ->with('total_estimate_licensee_inclusive_gst', $total_estimate_licensee_inclusive_gst)
        ->with('total_estimate_applicant_exclusive_gst', $total_estimate_applicant_exclusive_gst)
        ->with('gst', $gst)
        ->with('total_estimate_applicant_inclusive_gst', $total_estimate_applicant_inclusive_gst)
     	->with('area_type', $area_type)
        ->with('line_installation_option', $line_installation_option)
        ->with('length_of_underground_line', $length_of_underground_line)
        ->with('length_of_overhead_line', $length_of_overhead_line)
        ->with('load_range', $load_range);
  	}
  
  
   public function copyright_policy()
    {
    
        return view('frontend.copyright-policy');
    }
  
  public function hyperlink_policy()
    {
    
        return view('frontend.hyperlink-policy');
    }
  
  public function privacy_policy()
    {
        return view('frontend.privacy-policy');
    }
  
  public function terms_condition()
    {
        return view('frontend.terms-condition');
    }
  
  public function security_policy()
    {
        return view('frontend.security-policy');
    }
  
  public function accessibility_statement()
    {
        return view('frontend.accessibility-statement');
    }
  
  public function disclaimer()
    {
        return view('frontend.disclaimer');
    }
  
 public function help()
    {
        return view('frontend.help');
    }
  
 public function screen_reader_access()
    {
        return view('frontend.screen-reader-access');
    }
  
   public function feedback()
    {
        return view('frontend.feedback');
    }
  
  public function download_forms()
    {
        return view('frontend.download-forms');
    }
  
  
   public function faq()
    {
        return view('frontend.faq');
    }
  
   public function sitemap()
    {
        return view('frontend.sitemap');
    }
  
  public function about()
    {
        return view('frontend.about');
    }
  
  
  public function ImportantLink()
    {
    	$news_i = DB::table('news_master')
            ->where('status', '1')
            ->where('language', 'English')
            ->where('section', '1')
            ->orderBy('created_at', 'desc')
            ->get();
        return view('frontend.ImportantLink')->with('news_i', $news_i);
    }
  public function Highlights()
    {
     	$news_h = DB::table('news_master')
            ->where('status', '1')
            ->where('language', 'English')
            ->where('section', '2')
            ->orderBy('created_at', 'desc')
            ->get();
        return view('frontend.Highlights')->with('news_h', $news_h);
    }
  public function NewsNotifications()
    {
    	$news_n = DB::table('news_master')
            ->where('status', '1')
            ->where('language', 'English')
            ->where('section', '3')
            ->orderBy('created_at', 'desc')
            ->get();
        return view('frontend.NewsNotifications')->with('news_n', $news_n);
    }
  
  
  public function tarrif_order()
    {
        return view('frontend.tarrif-order');
    }
 
  
  
}
