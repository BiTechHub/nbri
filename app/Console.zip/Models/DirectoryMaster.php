namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DirectoryMaster extends Model
{
    protected $table = 'testingss';
    protected $fillable = ['name', 'area', 'designation'];
}
