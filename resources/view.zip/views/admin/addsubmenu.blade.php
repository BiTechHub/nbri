@extends('admin.layouts.master')
@section('main-section')
<div class="content-wrapper">
	  <div class="container">
		<!-- Content Header (Page header) -->
		<div class="content-header">
			<div class="d-flex align-items-center">
				<div class="mr-auto">
					<h3 class="page-title">Add Submenu</h3>
					<div class="d-inline-block align-items-center">
						<nav>
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="#"><i class="mdi mdi-home-outline"></i></a></li>
								<li class="breadcrumb-item" aria-current="page">Control</li>
								<li class="breadcrumb-item active" aria-current="page">Add Submenu</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<!-- Main content -->
		<section class="content">

		 <!-- Basic Forms -->
		  <div class="box">

			<!-- /.box-header -->
			<div class="box-body">
			  <div class="row">
				<div class="col">
					<form action="{{ route('admin-panel.uploadsubmenu') }}" method="post" enctype="multipart/form-data">
                    @if(session('status'))
                       <div class="alert alert-success">
                           {{ session('status') }}
                       </div>
                     @endif
					 @if(session('success'))
                       <div class="alert alert-success">
                           {{ session('success') }}
                       </div>
                     @endif
					 @if(session('fail'))
                       <div class="alert alert-success">
                           {{ session('fail') }}
                       </div>
                     @endif
                        @csrf
					<div class="row">
						<div class="col-12">
							<div class="form-group">
								<h5>Select Main Menu <span class="text-danger">*</span></h5>
								<div class="controls">
                                  <select name="main_cat" required class="form-control">
                                    <option selected value="">--Please Select--</option>
                                    @foreach($minu as $minus)
                                     <option value="{{$minus->id}}"   >{{ $minus->menu_name }}</option>
                                    @endforeach
                                  </select> 
								</div>
								@error('main_cat') 
									<div class="alert alert-danger mt-1 mb-1"> {{ $message }}</div> 
								@enderror
							</div>
						</div>
						<div class="col-6">
                          	<div class="form-group">
								<h5>Submenu Name <span class="text-danger">*</span></h5>
								<div class="controls">
									<input type="text" name="submenu" class="form-control"> </div>
							</div>
							@error('submenu') 
								<div class="alert alert-danger mt-1 mb-1"> {{ $message }}</div> 
							@enderror
                        </div>
						<div class="col-6">
							<div class="form-group">
							  <h5>सबमेनू नाम <span class="text-danger">*</span></h5>
							  <div class="controls">
								  <input type="text" name="submenu_hi" class="form-control"> </div>
						  </div>
						  @error('submenu_hi') 
							<div class="alert alert-danger mt-1 mb-1"> {{ $message }}</div> 
						@enderror
					  </div>
					</div>
					<div class="text-xs-right">
						<button type="submit" class="btn btn-info">Submit</button>
					</div>
					</form>
				</div>
				<!-- /.col -->
			  </div>

				<div class="box mt-20">
					<div class="box-header">
						<h4 class="box-title">Manage Submenu Item</h4>
					</div>
					<div class="box-body">
						<div class="table-responsive">
							<table id="complex_header" class="table table-striped table-bordered display" style="width:100%">
								<thead>
									<tr>
										<th>Serial No.</th>
										<th>Submenu Name</th>
										<th>Submenu Name(Hindi)</th>
										<th>Main Menu Name</th>
                                        <th>Action</th>
									</tr>
								</thead>
								<tbody>
									@php
									$i=1;
									@endphp
									@foreach($ruchi as $item)
									<tr>
										<td>{{$i}}</td>
										<td>{{$item->sub_name}}</td>
										<td>{{$item->submenu_hi}}</td>
										<td>
                                          {{ DB::table('menus')->where('id', $item->cat_name)->where('isDeleted', 'N')->first()->menu_name }}
                                     	 </td>

										<td>
                                           <button class="btn btn-info" data-toggle="modal" type="button" data-target="#update_modal{{$item->id}}">
                                          <i class="fa fa-edit"></i>
                                        </button>
                                        <!-- update slider image  Shani-->
                                        <div class="modal fade" id="update_modal{{$item->id}}" aria-hidden="true">
                                          <div class="modal-dialog">
                                            <div class="modal-content">
                                              <div class="modal-header">
                                                <h3 class="modal-title">Update Submenu</h3>
                                              </div>
                                              <div class="modal-body">
                                                <form action="{{url('/')}}/admin-panel/update_submenu" method="post" enctype="multipart/form-data"> 
                                                  @csrf
                                                  <div class="row">
                                                    <div class="col-12">
                                                      <input type="hidden" name="user_id" value="{{$item->id}}"/>
                                                      <div class="form-group">
                                                        <h5>Submenu Name <span class="text-danger">*</span></h5>
                                                        <div class="controls">
                                                          <input type="text" name="sub_name" class="form-control"  value="{{$item->sub_name}}"></div>
                                                        @error('sub_name') <div class="alert alert-danger mt-1 mb-1"> {{ $message }}</div> @enderror
                                                      </div>
                                                    </div>
                                                    <div class="col-12">
                                                      <div class="form-group">
                                                        <h5>सबमेनू नाम <span class="text-danger">*</span></h5>
                                                        <div class="controls">
                                                          <input type="text" name="submenu_hi" class="form-control" value="{{$item->submenu_hi}}"></div>
                                                        @error('submenu_hi') <div class="alert alert-danger mt-1 mb-1"> {{ $message }}</div> @enderror
                                                      </div>
                                                    </div>
                                                  </div>
                                                  <div style="clear:both;"></div>
                                                  <div class="modal-footer">
                                                    <button name="update" class="btn btn-primary" type="submit"><span>&#10004;</span> Update</button>
                                                    <button class="btn btn-danger" type="button" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Close</button>
                                                  </div>
                                                </form>

                                              </div>
                                            </div>
                                          </div>
                                          </div>
                                          
                                          <a href="{{url('/')}}/admin-panel/submenudel/{{$item->id}}" class="delete btn btn-danger"><i class="fa fa-trash"></i></a></td>
									</tr>
									@php
									$i++;
									@endphp
                                  @endforeach
								</tbody>
							</table>
						</div>
					</div>
				</div>
			  <!-- /.row -->
			</div>
			<!-- /.box-body -->
		  </div>
		  <!-- /.box -->
		</section>
		<!-- /.content -->
	  </div>
  </div>

  @endsection
@section('script')
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
 <script type="text/javascript">

 $('.delete').on('click', function (event) {
    event.preventDefault();
    const url = $(this).attr('href');
    swal({
        title: 'Are you sure?',
        text: 'This record and it`s details will be permanantly deleted!',
        icon: 'warning',
        buttons: ["Cancel", "Yes!"],
    }).then(function(value) {
        if (value) {
            window.location.href = url;
        }
    });
});

 </script>
@endsection
